let truck;
let items = [];
let scoreCity = 0;
let scoreField = 0;
let combo = 0;
let imbalanceWarning = "";
let gameOver = false;

let level = 1;
let levelDuration = 10000; // 10 segundos por nível
let lastLevelUpTime = 0;
let spawnInterval = 1600;
let lastSpawnTime = 0;

let gameStarted = false;

function setup() {
  createCanvas(800, 400);
  truck = new Truck();
  textAlign(CENTER, CENTER);
  lastLevelUpTime = millis();
}

function draw() {
  background(135, 206, 235);
  drawScene();

  if (!gameStarted) {
    drawInstructions();
    return;
  }

  if (!gameOver) {
    truck.update();
    truck.show();

    let currentTime = millis();

    if (currentTime - lastLevelUpTime > levelDuration) {
      level++;
      lastLevelUpTime = currentTime;
      spawnInterval = max(500, spawnInterval - 200);
    }

    if (currentTime - lastSpawnTime > spawnInterval) {
      spawnItem();
      lastSpawnTime = currentTime;
    }

    for (let item of items) {
      item.update();
      item.show();
      item.speed = 2 + level * 0.7; // aumenta velocidade conforme nível
    }

    checkDeliveries();
    removeOffscreenItems();

    drawUI();
    drawBalanceBar();
    checkImbalance();
    checkVictory();
  } else {
    showGameOver();
  }
}

function mousePressed() {
  if (!gameStarted) {
    startGame();
  } else if (gameOver) {
    restartGame();
  }
}

function keyPressed() {
  if (!gameStarted) return;
  if (keyCode === UP_ARROW) truck.move(-1);
  if (keyCode === DOWN_ARROW) truck.move(1);
}

function drawScene() {
  // Fundo Campo e Cidade com detalhes
  // Campo
  fill(100, 180, 100);
  rect(0, 0, width / 2, height);
  fill(255);
  textSize(20);
  textAlign(LEFT, CENTER);
  text("🌻 Campo", 40, 30);
  drawFieldDetails();

  // Cidade
  fill(180);
  rect(width / 2, 0, width / 2, height);
  fill(0);
  textSize(20);
  textAlign(LEFT, CENTER);
  text("🏙️ Cidade", width / 2 + 40, 30);
  drawCityDetails();

  // Trilhos
  stroke(100);
  strokeWeight(4);
  let tracks = [100, 200, 300];
  for (let y of tracks) {
    line(0, y + 15, width, y + 15);
  }
  noStroke();
}

function drawFieldDetails() {
  // Flores e plantas na área do campo
  fill(255, 215, 0);
  for(let i = 0; i < 10; i++) {
    ellipse(30 + i * 35, 360 + sin(frameCount * 0.1 + i) * 5, 15, 20);
  }
  fill(34,139,34);
  for(let i = 0; i < 8; i++) {
    ellipse(20 + i * 45, 320 + cos(frameCount * 0.1 + i) * 7, 10, 15);
  }
}

function drawCityDetails() {
  // Prédios simplificados na cidade
  fill(150);
  for (let i = 0; i < 6; i++) {
    let x = width / 2 + 40 + i * 90;
    let h = 80 + (i % 3) * 40;
    rect(x, height - h - 10, 50, h, 5);
    fill(255, 255, 224);
    for (let y = height - h; y < height - 10; y += 20) {
      for (let xWin = x + 5; xWin < x + 50; xWin += 15) {
        rect(xWin, y, 10, 10);
      }
    }
    fill(150);
  }
}

function drawUI() {
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text("Entregas para o Campo: " + scoreField, 10, 60);
  text("Entregas para a Cidade: " + scoreCity, 10, 80);
  text("Nível: " + level, 10, 100);
  if (imbalanceWarning) {
    fill(255, 0, 0);
    textSize(18);
    textAlign(CENTER);
    text(imbalanceWarning, width / 2, height - 30);
    textAlign(LEFT);
  }
}

function drawBalanceBar() {
  let barWidth = 200;
  let centerX = width / 2 - barWidth / 2;
  let diff = scoreCity - scoreField;
  fill(240);
  rect(centerX, 10, barWidth, 10);
  fill(50, 150, 255);
  let balance = map(diff, -10, 10, 0, barWidth);
  balance = constrain(balance, 0, barWidth);
  rect(centerX, 10, balance, 10);
  stroke(0);
  line(centerX + barWidth / 2, 10, centerX + barWidth / 2, 20);
  noStroke();
}

function checkDeliveries() {
  // Pontuação com valores diferentes por tipo + bônus combos
  for (let i = items.length - 1; i >= 0; i--) {
    if (truck.hits(items[i])) {
      let item = items[i];
      if (item.toCity) {
        scoreCity += item.value;
      } else {
        scoreField += item.value;
      }
      combo++;
      // Bônus para combos de 4
      if (combo % 4 === 0) {
        scoreCity += item.toCity ? 2 : 0;
        scoreField += item.toCity ? 0 : 2;
      }
      items.splice(i, 1);
    }
  }
}

function removeOffscreenItems() {
  items = items.filter(i => !i.offscreen);
}

function checkImbalance() {
  if (abs(scoreCity - scoreField) >= 6) {
    imbalanceWarning = "⚠️ Entregas desequilibradas!";
  } else {
    imbalanceWarning = "";
  }
}

function checkVictory() {
  if (scoreCity >= 40 && scoreField >= 40) {
    gameOver = true;
  }
}

function showGameOver() {
  fill(0, 180);
  rect(0, 0, width, height);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(28);
  text("🎉 Conexão Campo-Cidade Equilibrada! 🎉", width / 2, height / 2 - 20);
  textSize(18);
  text("Clique para jogar novamente", width / 2, height / 2 + 20);
}

function restartGame() {
  scoreCity = 0;
  scoreField = 0;
  items = [];
  gameOver = false;
  combo = 0;
  level = 1;
  spawnInterval = 1600;
  lastLevelUpTime = millis();
}

function spawnItem() {
  let yOptions = [100, 200, 300];
  let y = random(yOptions);
  let toCity = random() < 0.5;

  // Mais variedade de itens com ícones, valores e categorias:
  let fieldItems = [
    {label:"🍅 Tomate", value:1},
    {label:"🌽 Milho", value:2},
    {label:"🥕 Cenoura", value:1},
    {label:"🍓 Morango", value:3},
    {label:"🍯 Mel", value:2}
  ];

  let cityItems = [
    {label:"🛠️ Ferramenta", value:1},
    {label:"👕 Roupa", value:2},
    {label:"📦 Caixa", value:1},
    {label:"📱 Celular", value:3},
    {label:"🚗 Peça de carro", value:2}
  ];

  let itemData = toCity ? random(cityItems) : random(fieldItems);
  items.push(new Item(toCity, y, itemData.label, itemData.value));
}

function drawInstructions() {
  fill(0, 180);
  rect(0, 0, width, height);
  fill(255);
  textSize(20);
  textAlign(CENTER, CENTER);
  text("Mantenha as entregas equilibradas para evitar o aviso vermelho,\ne para iniciar o jogo clique na tela", width / 2, height / 2);
}

function startGame() {
  gameStarted = true;
  lastLevelUpTime = millis();
  lastSpawnTime = 0;
  spawnInterval = 1600;
  spawnItem();
}

class Truck {
  constructor() {
    this.x = width / 2 - 30;
    this.yIndex = 1;
    this.yOptions = [100, 200, 300];
    this.y = this.yOptions[this.yIndex];
    this.smoke = [];
  }

  move(dir) {
    this.yIndex = constrain(this.yIndex + dir, 0, this.yOptions.length - 1);
    this.y = this.yOptions[this.yIndex];
  }

  update() {
    this.smoke.push({ x: this.x - 15, y: this.y + 5, r: random(8, 14) });
    if (this.smoke.length > 10) this.smoke.shift();
  }

  show() {
    for (let s of this.smoke) {
      fill(200, 200, 200, 120);
      ellipse(s.x, s.y, s.r);
    }

    fill(240, 100, 100);
    rect(this.x, this.y, 40, 30, 5);

    fill(255, 200, 0);
    rect(this.x + 40, this.y + 5, 25, 20, 4);

    fill(180);
    rect(this.x + 45, this.y + 8, 12, 10, 2);

    fill(255, 255, 100);
    ellipse(this.x + 65, this.y + 15, 6, 6);

    fill(50);
    ellipse(this.x + 10, this.y + 30, 10, 10);
    ellipse(this.x + 50, this.y + 30, 10, 10);
  }

  hits(item) {
    return dist(this.x + 30, this.y + 15, item.x, item.y + 15) < 30;
  }
}

class Item {
  constructor(toCity, y, label, value) {
    this.toCity = toCity;
    this.y = y;
    this.speed = 3;
    this.x = toCity ? 0 : width;
    this.offscreen = false;
    this.label = label;
    this.value = value;
  }

  update() {
    this.x += this.toCity ? this.speed : -this.speed;
    if (this.x < -30 || this.x > width + 30) this.offscreen = true;
  }

  show() {
    fill(this.toCity ? color(0, 150, 0) : color(0, 0, 180));
    ellipse(this.x, this.y + 15, 30, 30);
    fill(255);
    textSize(14);
    textAlign(CENTER, CENTER);
    text(this.label, this.x, this.y + 15);
    textAlign(LEFT);
  }
}